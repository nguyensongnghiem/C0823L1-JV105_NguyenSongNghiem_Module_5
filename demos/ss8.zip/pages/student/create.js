function StudentCreate() {
    return(
        <>
            <h1>Thêm mới</h1>
        </>
    )
}

export default StudentCreate;